package com.mkef.tiers.mixin;

import com.mkef.tiers.TierData;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class EntityMixin {
    @Inject(method = "getDisplayName", at = @At("RETURN"), cancellable = true)
    private void mkef$tier(CallbackInfoReturnable<Component> cir) {
        cir.setReturnValue(TierData.decorate(this, cir.getReturnValue()));
    }
}
