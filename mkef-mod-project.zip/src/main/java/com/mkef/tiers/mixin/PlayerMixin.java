package com.mkef.tiers.mixin;

import com.mkef.tiers.TierData;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Player.class)
public abstract class PlayerMixin {
    // require = 0: إذا Player ما يعدّل الدالة بنفسه، نكتفي بـ EntityMixin
    @Inject(method = "getDisplayName", at = @At("RETURN"), cancellable = true, require = 0)
    private void mkef$tier(CallbackInfoReturnable<Component> cir) {
        cir.setReturnValue(TierData.decorate(this, cir.getReturnValue()));
    }
}
