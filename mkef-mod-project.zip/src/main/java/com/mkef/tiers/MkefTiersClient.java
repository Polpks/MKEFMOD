package com.mkef.tiers;

import net.fabricmc.api.ClientModInitializer;

import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class MkefTiersClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // يحدّث الرانكات من الموقع كل 5 دقائق
        Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "mkef-tiers");
            t.setDaemon(true);
            return t;
        }).scheduleAtFixedRate(TierData::refresh, 0, 5, TimeUnit.MINUTES);
    }
}
