package com.mkef.tiers;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.serialization.JsonOps;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentSerialization;
import net.minecraft.world.entity.player.Player;

import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class TierData {
    // الرابط يُقرأ من ملف config/mkeftiers.txt (ينشأ تلقائياً أول تشغيل)
    private static final String DEFAULT_URL = "https://polpks.github.io/MKEFTIERS/players.json";

    private static final Map<String, Integer> PTS = Map.of(
            "HT1", 60, "LT1", 44, "HT2", 32, "LT2", 20, "HT3", 10,
            "LT3", 6, "HT4", 4, "LT4", 3, "HT5", 2, "LT5", 1);
    // أيقونة كل وضع (اسم صورة العنصر في ماينكرافت)
    private static final Map<String, String> ICONS = Map.ofEntries(
            Map.entry("sword", "diamond_sword"), Map.entry("axe", "diamond_axe"), Map.entry("mace", "mace"),
            Map.entry("spearmace", "diamond_spear"), Map.entry("uhc", "golden_apple"),
            Map.entry("nethpot", "netherite_helmet"), Map.entry("pot", "splash_potion"),
            Map.entry("smp", "ender_pearl"), Map.entry("diasmp", "diamond_chestplate"),
            Map.entry("crystal", "end_crystal"), Map.entry("tntcart", "tnt_minecart"));
    private static final Map<String, String> COLORS = Map.of(
            "1", "#f2b01e", "2", "#c9d3e3", "3", "#d98a4a", "4", "#7fa6d9", "5", "#8793a8");

    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(8)).build();
    private static volatile Map<String, String[]> best = Map.of();
    private static final Map<String, Component> CACHE = new ConcurrentHashMap<>();

    private TierData() {}

    private static String readUrl() throws Exception {
        Path f = FabricLoader.getInstance().getConfigDir().resolve("mkeftiers.txt");
        if (!Files.exists(f)) Files.writeString(f, DEFAULT_URL + "\n");
        return Files.readString(f).trim();
    }

    public static void refresh() {
        try {
            String url = readUrl();
            if (url.isEmpty() || url.contains("YOUR-SITE")) return;
            HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                    .timeout(Duration.ofSeconds(10)).GET().build();
            HttpResponse<String> res = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
            if (res.statusCode() == 200) parse(res.body());
        } catch (Exception ignored) {
            // بدون إنترنت أو الرابط غلط: نبقي آخر بيانات محفوظة
        }
    }

    private static void parse(String body) {
        JsonArray arr = JsonParser.parseString(body).getAsJsonArray();
        Map<String, String[]> out = new HashMap<>();
        for (JsonElement el : arr) {
            JsonObject p = el.getAsJsonObject();
            String name = p.get("n").getAsString().toLowerCase(Locale.ROOT);
            int bestPts = 0;
            String[] pick = null;
            for (var e : p.getAsJsonObject("t").entrySet()) {
                String tier = e.getValue().getAsString().toUpperCase(Locale.ROOT);
                Integer pts = PTS.get(tier);
                if (pts != null && pts > bestPts) {
                    bestPts = pts;
                    pick = new String[]{e.getKey(), tier};
                }
            }
            if (pick != null) out.put(name, pick);
        }
        best = out;
        CACHE.clear();
    }

    private static Component prefixFor(String playerName) {
        String key = playerName.toLowerCase(Locale.ROOT);
        String[] e = best.get(key);
        if (e == null) return null;
        return CACHE.computeIfAbsent(key, k -> build(e[0], e[1]));
    }

    private static Component build(String mode, String tier) {
        String icon = ICONS.getOrDefault(mode, "diamond_sword");
        String json = "{\"text\":\"\",\"extra\":["
                + "{\"type\":\"object\",\"atlas\":\"minecraft:items\",\"sprite\":\"minecraft:item/" + icon + "\"},"
                + "{\"text\":\" " + tier + " \",\"color\":\"" + COLORS.get(tier.substring(2)) + "\",\"bold\":true}]}";
        return ComponentSerialization.CODEC.parse(JsonOps.INSTANCE, JsonParser.parseString(json))
                .result().orElseGet(() -> Component.literal(tier + " "));
    }

    /** يضيف الأيقونة والتير قبل اسم اللاعب */
    public static Component decorate(Object self, Component original) {
        if (!(self instanceof Player player)) return original;
        Component prefix = prefixFor(player.getName().getString());
        if (prefix == null) return original;
        if (original.getString().startsWith(prefix.getString())) return original; // لا نكرر
        return Component.empty().append(prefix).append(original);
    }
}
